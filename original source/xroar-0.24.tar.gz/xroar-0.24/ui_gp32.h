/*  XRoar - a Dragon/Tandy Coco emulator
 *  Copyright (C) 2003-2010  Ciaran Anscomb
 *
 *  See COPYING.GPL for redistribution conditions. */

#ifndef XROAR_UI_GP32_H_
#define XROAR_UI_GP32_H_

void gp32_main_loop(void);

#endif  /* XROAR_UI_GP32_H_ */
