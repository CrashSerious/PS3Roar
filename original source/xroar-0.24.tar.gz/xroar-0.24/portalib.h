/* Public domain portability stuff */

#ifndef XROAR_PORTALIB_H_
#define XROAR_PORTALIB_H_

#ifdef NEED_STRSEP
char *strsep(char **stringp, const char *delim);
#endif

#endif  /* XROAR_PORTALIB_H_ */
