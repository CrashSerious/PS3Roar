#ifndef XROAR_GP32_GPLIB_H_
#define XROAR_GP32_GPLIB_H_

#include "../types.h"

char *gm_strdup(const char *s1);

#endif  /* XROAR_GP32_GPLIB_H_ */
