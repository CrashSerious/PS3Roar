/*  XRoar - a Dragon/Tandy Coco emulator
 *  Copyright (C) 2003-2010  Ciaran Anscomb
 *
 *  See COPYING.GPL for redistribution conditions. */

#ifndef XROAR_AO_GP32_H_
#define XROAR_AO_GP32_H_

void sound_silence(void);

#endif  /* XROAR_AO_GP32_H_ */
